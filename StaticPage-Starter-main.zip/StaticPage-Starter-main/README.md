# StaticPage
Static website for GitHub Actions deployment example.
 
